<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Master_kode_surat extends Model
{
    use HasFactory;

    protected $guarded = [];

}
