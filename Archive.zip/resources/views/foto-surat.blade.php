<div>
    <a href="{{url('storage/'.$model->foto)}}" target="__blank"><img src="{{url('storage/'.$model->foto)}}" alt="" style="width: 200px"></a>
</div>
