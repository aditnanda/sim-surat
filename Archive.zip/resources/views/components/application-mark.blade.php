<img src="{{asset('logo.png')}}" alt="" srcset="" class="h-10">
