<a href="/">
<img src="{{asset('logo.png')}}" alt="" srcset="" class="h-16">

</a>
